#include <stdio.h>
#include <string.h>
#include <stdlib.h> // For system("cls") or system("clear")

#define USER_ID_LENGTH 20
#define PASSWORD_LENGTH 20

typedef struct{
    char user_id[USER_ID_LENGTH];
    char password[PASSWORD_LENGTH];
    double balance;
} Account;

Account account;
int is_account_created = 0;

void clearScreen() {
    // This clears the console screen. Use 'cls' for Windows and 'clear' for UNIX/Linux.
    #ifdef _WIN32
        system("cls"); 
    #else
        system("clear");
    #endif
}

void createAccount() {
    clearScreen();
    printf("                     Create a new bank account:\n");
    printf("                     Please enter your user id: ");
    scanf("                      %s", account.user_id);
    printf("                     Please enter your password: ");
    scanf("%s", account.password);
    account.balance = 0.0; // Initialize balance to 0
    is_account_created = 1; // Mark account as created
    printf("                  ------- ---------------------------------")
    printf("                   Thank You! Your account has been created!\n");
    printf("                 -------------------------------------------")
    printf("                    ...Press Enter to continue...");
    getchar(); getchar(); // Wait for Enter key
}

int login() {
    clearScreen();
    char user_id[USER_ID_LENGTH], password[PASSWORD_LENGTH];
    printf("                        Login to your account:\n");
    printf("                        Please enter your user id: ");
    scanf("                         %s", user_id);
    printf("                        Please enter your password: ");
    scanf("%s", password);

    if(is_account_created && strcmp(account.user_id, user_id) == 0 && strcmp(account.password, password) == 0) {
    	printf("                ---------------------------------")
        printf("                    Access Granted!\n");
        printf("                ---------------------------------")
        // User successfully logged in and can perform actions
        return 1; // Successful login
    } else {
    	printf("                 ---------------------------------")
        printf("\n                    *** LOGIN FAILED! ***\n");
        printf("                 ---------------------------------")
        printf("                    ...Press Enter to continue...");
        getchar(); getchar(); // Wait for Enter key
        return 0; // Unsuccessful login
    }
}

void mainMenu() {
    char choice;
    do {
        clearScreen();
        printf("                  d -> Deposit Money\n");
        printf("                  w -> Withdraw Money\n");
        printf("                  r -> Request Balance\n");
        printf("                  q -> Quit\n");
        printf("> ");
        scanf(" %c", &choice); // Added space before %c to consume any leftover newline

        switch (choice) {
        case 'd': {
            double amount;
            printf("            ---------------------------------")
            printf("                Amount of deposit: $");
            printf("            ---------------------------------")
            scanf("%lf", &amount);
            account.balance += amount; // Update balance
            printf("             ---------------------------------")
            printf("              Successfully deposited $%.2lf.\n", amount);
            printf("             ---------------------------------")
            break;
        }
        case 'w': {
            double amount;
            printf("          ---------------------------------")
            printf("              Amount of withdrawal: $");
            printf("          ---------------------------------")
            scanf("%lf", &amount);
            if (amount > account.balance) {
            	printf("      ---------------------------------")
                printf("            Insufficient funds!\n");
                printf("       ---------------------------------")
            } else {
                account.balance -= amount; // Update balance
                printf("          ------------------------------------")
                printf("           Successfully withdrawn $%.2lf.\n", amount);
                printf("          -------------------------------------")
            }
            break;
        }
        case 'r':
        	printf("            ---------------------------------")
            printf("\t\t\t\t\t      Your balance is $%.2lf.\n", account.balance);
            printf("             ---------------------------------")
            break;
        case 'q':
        	printf("                 ---------------------------------")
            printf("\t\t\t\t\t        Thank you for using the ATM.\n");
            printf("                 ---------------------------------")
            break;
        default:
            printf("\t\t\t\t\t      Invalid option. Please try again.\n");
            break;
        }
        
        printf("\t\t\t\t\t ....Press Enter to continue...");
        getchar(); getchar(); // Wait for Enter key
        
    } while (choice != 'q');
}

int main() {
    char option;

    do {
        clearScreen();
        printf("=================== Hi! Welcome to the ATM Machine!====================\n");
        printf("               Please select an option from the menu below:\n");
        printf("                          l -> Login\n");
        printf("                          c -> Create New Account\n");
        printf("                          q -> Quit\n");
        printf("                          >... ");
        scanf(" %c", &option);

        if (option == 'l') {
            if (login()) {
                mainMenu(); // Show main menu for logged-in users
            }
        } else if (option == 'c') {
            createAccount();
        } else if (option == 'q') {
            printf("===============Thank you for using the ATM. Goodbye!================\n");
        } else {
            printf("===============Invalid option. Please try again.=====================\n");
        }

    } while (option != 'q');

    return 0;
}

