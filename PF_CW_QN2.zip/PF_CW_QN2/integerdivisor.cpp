#include <iostream>

using namespace std;

// Function to print the positive divisors in decreasing order
void printDivisors(int number) {
    for (int i = number; i > 0; --i) {
        if (number % i == 0) {
            cout << i << endl; // Print the divisor
        }
    }
}

int main() {
    int number;
    char choice;

    cout << "This program will display all positive divisors of a positive integer "
         << "in decreasing order." << endl;

    do {
        cout << "Please enter a positive integer: ";
        cin >> number;

        if (number <= 0) {
            cout << number << " is not a positive integer." << endl;
            // No valid option to end; just continue trying to enter an integer.
            continue; 
        }

        // Print divisors if a positive integer is entered
        printDivisors(number);

        do {
            cout << "Would you like to see the divisors of another integer (Y/N)? ";
            cin >> choice;

            // Handle invalid input
            if (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n') {
                cout << "Please respond with Y (or y) for yes and N (or n) for no." << endl;
            }
        } while (choice != 'Y' && choice != 'y' && choice != 'N' && choice != 'n');

    } while (choice == 'Y' || choice == 'y');

    return 0;
 } 
