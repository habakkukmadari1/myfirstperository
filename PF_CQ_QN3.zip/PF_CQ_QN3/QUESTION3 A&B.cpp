#include <iostream>
using namespace std;

// (a) Function that calculates the sum of all integers from 'first' to 'last' inclusive
int sum_from_to(int first, int last) {
    int sum = 0;
    for (int i = first; i <= last; ++i) {
        sum += i; // Add each integer in the range to sum
    }
    return sum; // Return the total sum
}

// Helper function to compute GCD using the Euclidean algorithm
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a; // Return the greatest common divisor
}

// (b) Function that reduces a fraction represented by num and denom
int reduce(int &num, int &denom) {
    // Check if either num or denom is zero or negative
    if (num <= 0 || denom <= 0) {
        return 0; // Indicate failure to reduce
    }

    int common_divisor = gcd(num, denom); // Get the greatest common divisor
    num /= common_divisor; // Reduce numerator
    denom /= common_divisor; // Reduce denominator

    return 1; // Indicate successful reduction
}

int main() {
    // Testing the sum_from_to function
    int first, last;
    cout << "Enter two integers (first and last) to calculate their sum: ";
    cin >> first >> last;

    int sum = sum_from_to(first, last);
    cout << "The sum of integers from " << first << " to " << last << " is: " << sum << endl;

    // Testing the reduce function
    int numerator, denominator;
    cout << "Enter numerator and denominator to reduce the fraction: ";
    cin >> numerator >> denominator;

    int result = reduce(numerator, denominator);
    if (result == 0) {
        cout << "Failed to reduce. Both numerator and denominator must be positive." << endl;
    } else {
        cout << "Reduced fraction: " << numerator << "/" << denominator << endl;
    }

    return 0;
}

